package com.app.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="topics")
@Getter
@Setter
public class Topic extends BaseEntity{
	@Column(name="name")
	private String topicName;
}
